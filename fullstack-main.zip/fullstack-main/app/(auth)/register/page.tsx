
import MultiStepRegisterForm from '@/components/mvpblocks/multi-step-form'

export default function RegisterPage() {
  return <MultiStepRegisterForm />
}
