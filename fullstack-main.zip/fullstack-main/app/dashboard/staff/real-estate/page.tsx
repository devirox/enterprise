import React from 'react'

export default function StaffRealEstate() {
  return (
    <div className="p-6 text-xl font-semibold">Real Estate Staff Placeholder</div>
  )
}
