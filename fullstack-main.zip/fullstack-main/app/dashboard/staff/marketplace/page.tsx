import React from 'react'

export default function StaffMarketplace() {
  return (
    <div className="p-6 text-xl font-semibold">Marketplace Staff Placeholder</div>
  )
}
