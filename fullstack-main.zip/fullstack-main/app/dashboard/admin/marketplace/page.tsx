import React from 'react'

export default function AdminMarketplace() {
  return (
    <div className="p-6 text-xl font-semibold">Marketplace Admin Placeholder</div>
  )
}
